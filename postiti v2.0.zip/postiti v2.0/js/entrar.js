const form = document.getElementById('acessoUsuario')
const usuarios = JSON.parse(localStorage.getItem('usuariosCadastrados'))
const erroUsuario = new bootstrap.Modal('#erroUsuario')
const erroLogin = new bootstrap.Modal('#erroLogin')

form.addEventListener('submit', (event) => {
    event.preventDefault()

    if(!form.checkValidity()){
        form.classList.add('was-validated')
        return
    }

    const userForm = form.emailUsuario.value
    const senhaForm = form.senhaUsuario.value
    
    const buscaUsuario = (usuarios.some((element) => element.emailUsuario === userForm))

    if (!buscaUsuario) {
        erroUsuario.show()
        return
    }

    const confirmaUsuario = usuarios.findIndex((usuario) => {
        return usuario.emailUsuario === userForm
    })

    const confirmaSenha = usuarios.findIndex((senha) => {
        return senha.senhaUsuario === senhaForm
    })

    if(confirmaSenha === -1 || confirmaUsuario === -1) {
        erroLogin.show()
        return
    }

    localStorage.setItem('usuarioAtual', JSON.stringify(userForm))

    location.href = 'postiti.html'
})
