const usuarios = JSON.parse(localStorage.getItem('usuariosCadastrados') ?? '[]')
const capturaForm = document.getElementById('cadastroUsuario')
const erroSenha = new bootstrap.Modal('#erroSenha')
const erroEmail = new bootstrap.Modal('#erroEmail')
const fimCadastro = new bootstrap.Modal('#fimCadastro')

capturaForm.addEventListener('submit', (event) => {
    event.preventDefault()

    if(!capturaForm.checkValidity()){
        capturaForm.classList.add('was-validated')
        return
    }

    if(capturaForm.senhaUsuario.value !== capturaForm.senhaRepeat.value){
        erroSenha.show()
        return
    }

    const emailExiste = usuarios.some((usuario) => usuario.emailUsuario === capturaForm.emailUsuario.value)

    if(emailExiste) {
        erroEmail.show()
        return
    }
    
    
    const cadastroUsuario = {
        nomeUsuario: capturaForm.nomeUsuario.value,
        emailUsuario: capturaForm.emailUsuario.value,
        senhaUsuario: capturaForm.senhaUsuario.value,
        recados: []
    }
    
    usuarios.push(cadastroUsuario)    
    localStorage.setItem('usuariosCadastrados', JSON.stringify(usuarios))

    fimCadastro.toggle()
    document.getElementById('fechaModal').onclick = () => {location.href = './entrar.html'}    
})
