const cards = document.getElementById("listagem");

const modalErro = new bootstrap.Modal("#erroUsuario");
const modalSair = new bootstrap.Modal("#despedida");
const modalCadastro = new bootstrap.Modal("#modal-cadastro");
const modalApagar = new bootstrap.Modal("#modal-apagar");
const modalEditar = new bootstrap.Modal("#modal-editar");

const formRecado = document.getElementById("formRecado");
const formAtualiza = document.getElementById('formAtualiza')
const atualizaTitulo = document.getElementById('atualizaTitulo')
const atualizaRecado = document.getElementById('atualizaRecado')
let atualizaId = -1

const listaUsuarios = JSON.parse(localStorage.getItem("usuariosCadastrados"));
const usuarioAtual = listaUsuarios.find((e) => {
  return JSON.parse(localStorage.getItem("usuarioAtual")) === e.emailUsuario;
});
const indiceUsuario = listaUsuarios.findIndex((e) => {
  return JSON.parse(localStorage.getItem("usuarioAtual")) === e.emailUsuario;
});
const listaRecados = usuarioAtual.recados;

//Verifica se há um usuário logado
if (!JSON.parse(localStorage.getItem("usuarioAtual"))) {
  modalErro.show();
  document.getElementById("fechaModal").onclick = () => {
    location.href = "./entrar.html";
  };
}

//mostra nome do usuário da sessão no header
const titular = document.getElementById('titular')
titular.innerText = `Olá ${usuarioAtual.nomeUsuario} !`

//Carrega todas as mensagens na página
document.addEventListener("DOMContentLoaded", () => {
  listaRecados.forEach((element) => {
    novoCard(element);
  });  
});

//Adiciona Novo Card
function novoCard(recado) {
  const { id, titulo, msg } = recado;

  const col = document.createElement("div");
  col.setAttribute("class", "col-12 col-sm-6 col-lg-4 col-xl-3");
  col.setAttribute("id", `${id}`);

  const card = document.createElement("div");
  card.setAttribute("class", "card");

  const cardHeader = document.createElement("h5");
  cardHeader.setAttribute("class", "card-header cabecalho");
  cardHeader.innerText = `${titulo}`;

  const cardBody = document.createElement("div");
  cardBody.setAttribute("class", "card-body");

  const cardText = document.createElement("p");
  cardText.setAttribute("class", "card-text");
  cardText.innerText = `${msg}`;

  const btnEditar = document.createElement("button");
  btnEditar.setAttribute("class", "btn btn-editar me-1");
  btnEditar.addEventListener('click', () => {
    modalEditar.show()
    atualizaTitulo.value = titulo
    atualizaRecado.value = msg
    atualizaId = id    
  })
  btnEditar.innerHTML = `<i class="bi bi-pencil-square"></i>`;

  const btnExcluir = document.createElement("button");
  btnExcluir.setAttribute("class", "btn btn-excluir");
  btnExcluir.innerHTML = `<i class="bi bi-trash3"></i>`;
  btnExcluir.addEventListener("click", () => {
    modalApagar.show();
    const confirm = document.getElementById("apagaRecado");
    confirm.setAttribute("onclick", `apagarRecado(${id})`);
  });

  cardBody.appendChild(cardText);
  cardBody.appendChild(btnEditar);
  cardBody.appendChild(btnExcluir);

  card.appendChild(cardHeader);
  card.appendChild(cardBody);

  col.appendChild(card);

  cards.appendChild(col);
}

//Captura novos recados
formRecado.addEventListener("submit", () => {
  const tituloRecado = document.getElementById("tituloRecado").value;
  const msgRecado = document.getElementById("msgRecado").value;

  const novoRecado = {
    id: new Date().getTime(),
    titulo: tituloRecado,
    msg: msgRecado,
  };

  listaRecados.push(novoRecado);
  atualizaUsuario()
  formRecado.reset();
});

//Atualiza usuário com novas mensagens
function atualizaUsuario() {
  listaUsuarios.splice(indiceUsuario, 1, usuarioAtual);
  localStorage.setItem("usuariosCadastrados", JSON.stringify(listaUsuarios));  
}

//Modal Saída
document.getElementById("btnSair").addEventListener("click", () => {
  modalSair.show();
  document.getElementById("saidaModal").onclick = () => {
    location.href = "./entrar.html";
    localStorage.removeItem("usuarioAtual");
  };
});

//Apaga recados
function apagarRecado(id) {
  modalApagar.hide();
  const index = listaRecados.findIndex((recado) => recado.id === id);
  listaRecados.splice(index, 1);
  localStorage.setItem("usuariosCadastrados", JSON.stringify(listaUsuarios));

  const cardOut = document.getElementById(`${id}`);
  cardOut.remove();
}

//Editar recados
formAtualiza.addEventListener('submit', (e) => {
  e.preventDefault()
  modalEditar.hide()

  const index = listaRecados.findIndex(indice => indice.id === atualizaId)
  
  const novoRecado = {
    id: atualizaId,
    titulo: atualizaTitulo.value,
    msg: atualizaRecado.value
  };

  listaRecados.splice(index, 1, novoRecado)
  atualizaUsuario()
  location.reload()  
})
